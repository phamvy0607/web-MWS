<?php 
    session_start()
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MWS-Case Store</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="MWS.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" 
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="icon" href="img/product/Icon.jfif">
    <style>p.groove {border-style: groove;}</style>
</head>
<body>
    <!-- NAVIGATION -->
    <nav class="navbar navbar-expand-lg navbar-light bg-white py-3 fixed-top">
        <div class="container">
            <img src="../product/img1/logo1.png" alt="" width="100px" height="100px">        
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
            
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="MWS.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../product/indexx.html">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#featured">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../product/create_account.html">Sign up</a>
                    </li>
                    <li class="nav-item">
                        <i class="fal fa-search"></i>
                    </li>
                    <li>
                        <?php 
                            $count=0;
                            if(isset($_SESSION['cart']))
                            {
                                $count=count($_SESSION['cart']);
                            }
                        ?>
                        <a href="cart.php" class="nav-link btn "><i class="far fa-shopping-bag"></i>(<?php echo $count; ?>)</a>
                    </li> 
                </ul> <br> <br>
                <li class="nav-item" id="account-info" style="list-style: none;">
                    <button id="btn-login" class="btn btn-outline-dark ms-3" 
                    data-bs-toggle="modal" data-bs-target="#frm-login">Login</button>
                </li>
            </div>
        </div>
      </nav>

      <!-- Modal -->
    <form class="modal fade" id="frm-login" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="form-floating mb-3">
                        <input type="username" class="form-control" id="username" placeholder="Username" required>
                        <label for="username">Username</label>
                    </div>
                    <div class="form-floating">
                        <input type="password" class="form-control" id="password" placeholder="Password" required>
                        <label for="password">Password</label>
                    </div>
                </div>

                <div class="modal-footer border-0 justify-content-center">
                    <button type="submit" class="btn btn-success">Login</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </form>
    <div class="container mt-3">
        <div class="row product-list" id="product-list"></div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="js/database.js"></script>
    <script src="js/index.js"></script>
    
<!-- PHP -->
<select>
 <?php print_r($_SESSION['cart']) ?>
</select>
 
   
     <!-- home -->

    <section id="home">
        <form action="manage_cart.php" method="POST">
        <div class="container">
            <h5>NEW ARRIVALS</h5>
            <h1><span>Best Price</span> This Year</h1>
            <p>100% Natural Wood</p>
            <button class="btn-infor" type="submit" name="Add_To_Cart">Shop Now</button>
            <input type="hidden" name="Item_Name" value="New">
            <input type="hidden" name="Price" value="50.00">
        </div>
        </form>
    </section>

    <section id="brand" class="container">
        <div class="row m-0 py-5">
            <img class="img-fluid col-lg-2 col-md-4 col-6" src="../product/img1/1.png" alt="">
            <img class="img-fluid col-lg-2 col-md-4 col-6" src="../product/img1/2.png" alt="">
            <img class="img-fluid col-lg-2 col-md-4 col-6" src="../product/img1/3.png" alt="">
            <img class="img-fluid col-lg-2 col-md-4 col-6" src="../product/img1/4.png" alt="">
            <img class="img-fluid col-lg-2 col-md-4 col-6" src="../product/img1/5.png" alt="">
            <img class="img-fluid col-lg-2 col-md-4 col-6" src="../product/img1/6.png" alt="">
        </div>
    </section>

    <section id="new" class="w-100">
        <form action="manage_cart.php" method="POST">
        <div class="row p-0 m-0" >
            <div class="one col-lg-4 col-md-12 col-12 p-0">
                <img class="img-fluid" src="../product/img1/Iphone12.jpg" alt="" width="400px" height="400px">
                <div class="details">
                    <h2> IPHONE WOODEN CASE</h2>
                    <button class="text-uppercase btn-infor" name="Add_To_Cart" type="submit">Shop now</button>
                    <input type="hidden" name="Item_Name" value="IPHONE">
                    <input type="hidden" name="Price" value="50.00">
                </div>
            </div>
            <div class="one col-lg-4 col-md-12 col-12 p-0">
                <img class="img-fluid" src="../product/img1/ss_S9P.jpg" alt="" width="400px" height="400px">
                <div class="details">
                    <h2> SAMSUNG WOODEN CASE</h2>
                    <button class="text-uppercase btn-infor" name="Add_To_Cart" type="submit">Shop now</button>
                    <input type="hidden" name="Item_Name" value="SAMSUNG">
                    <input type="hidden" name="Price" value="40.00">
                </div>
            </div>
            <div class="one col-lg-4 col-md-12 col-12 p-0">
                <img class="img-fluid" src="../product/img1/Sony_Xperia5.jpg" alt="" width="400px" height="400px">
                <div class="details">
                    <h2> SONY WOODEN CASE</h2>
                    <button class="text-uppercase btn-infor" name="Add_To_Cart" type="submit">Shop now</button>
                    <input type="hidden" name="Item_Name" value="SONY">
                    <input type="hidden" name="Price" value="50.00">
                </div>
            </div>
        </form>
        </div>
    </section>


    <!-- PRODUCTS -->
    <section id="new_arrivals" class="my-5 pb-5">
        <div class="container text-center mt-5 py-5">
            <h3>New Arrivals</h3>
            <hr class="mx-auto">
            <p>Here you can check out our new products with fair price on MWS.</p>
        </div>
        <form action="manage_cart.php" method="POST">
        <div class="row mx-auto container-fluid">
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/Iphone13ProMax_Charcol.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Iphone 13ProMax - Charcol</h5>
                <h4 class="p-price">$50.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Iphone 13">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/Sony_XperiaX_PUWood.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Sony XperiaX - PU Wood</h5>
                <h4 class="p-price">$50.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Sony X">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/HTC10-Wood.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">HTC 10 - Natural Wood</h5>
                <h4 class="p-price">$50.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="HTC 10">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/LGG6_RetroWoodGrain.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">LG G6 - Retro Wood Grain</h5>
                <h4 class="p-price">$50.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="LG G6">
                <input type="hidden" name="Price" value="50.00">
            </div>
        </div>
    </form>
    </section>

    <section id="banner" class="my-5 py-5">
    <form action="manage_cart.php" method="POST">
        <div class="container">
            <h4>MID SEASON'S SALE</h4>
            <h1>Autumn Collection <br> UP TO 20% OFF</h1>
            <button type="submit" class="text-uppercase btn-infor" name="Add_To_Cart">Shop Now</button>
            <input type="hidden" name="Item_Name" value="Autumn">
            <input type="hidden" name="Price" value="50.00">
        </div>
    </form>
    </section>

    <section id="featured" class="my-5">
        <div class="container text-center mt-5 py-5">
            <h3>Our Products</h3>
            <hr class="mx-auto">
            <p>Here you can check out our products with fair price on MWS.</p>
        </div>
        <form action="manage_cart.php">
        <div class="row mx-auto container-fluid">
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/Iphone12.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Iphone 12 - Natural Wood</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Iphone 12">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/motorolaMotoG7_HickoryWood.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Motorola Moto G7 - Hickory Wood</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Motorola">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/nexus5.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Nexus 5 - Bamboo</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="nexus5">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/ssGalaxyS10+_BearMerbauWC.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Samsung Galaxy S10+ - Bear Merbau Wood</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Galaxy S10+">
                <input type="hidden" name="Price" value="50.00">
            </div>

            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/Sony_XperiaXA_FoxMerbauWC.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Sony XperiaXA - Fox Merbau Wood</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Sony XA">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/LGV40ThinQ_LightWalnutWood.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">LG V40 ThinQ - Light Walnut Wood</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="LG V40">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/HTCOneX10_WalnutWoodSlimHardShell.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">HTC One X10 - Walnut Wood Slim Hard Shell</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="HTC X10">
                <input type="hidden" name="Price" value="50.00">
            </div>
            <div class="product text-center col-lg-3 col-md-4 col-12">
                <img src="../product/img1/HuaweiP30Lite_OvileWC.jpg" alt="" class="img-fluid mb-3" width="450px" height="450px">
                <div class="star">
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                    <i class="fas fa-star"></i>
                </div>
                <h5 class="p-name">Huawei P30 Lite - Olive Wood</h5>
                <h4 class="p-price">$40.00</h4>
                <button type="submit" class="buy-btn btn-infor" name="Add_To_Cart">Buy Now</button>
                <input type="hidden" name="Item_Name" value="Huawei">
                <input type="hidden" name="Price" value="50.00">
            </div>
        </div>
    </form>
    </section>

    <!-- Footer -->
    <footer id="footer" class="mt-5 py-5">
        <div class="row container mx-auto pt-5">
            <div class="footer-one col-lg-3 col-md-6 col-12">
                <h1 style="color: #fff;">MWS</h1>
                <p class="pt-3">Become part of the WMS family and join thousands of happy customers from all over the globe.
                    Be the first to hear about new products, exclusive discounts and more...</p>
            </div>
            <div class="footer-one col-lg-3 col-md-6 col-12 mb-3">
                <h5 class="pb-2">Featured</h5>
                <ul class="text-uppercase list-unstyled">
                    <li><a href="#new_arrivals">NEW ARRIVALS</a></li>
                    <li><a href="#banner">MID SEASON'S SALE</a></li>
                    <li><a href="#featured">OUR PRODUCTS</a></li>
                </ul>
            </div>
            <div class="footer-one col-lg-3 col-md-6 col-12 mb-3">
                <h5 class="pb-2">Contact Us</h5>
                <div>
                    <h6 class="text-uppercase">Address</h6>
                    <p>MWS CASE - 123 STREET NAME, CITY</p>
                </div>
                <div>
                    <h6 class="text-uppercase">Phone</h6>
                    <p>(081) 816-4768</p>
                </div>
                <div>
                    <h6 class="text-uppercase">Email</h6>
                    <p>MWS@gmail.com</p>
                </div>
            </div>
            <div class="footer-one col-lg-3 col-md-6 col-12">
                <h5 class="pb-2">Instagram</h5>
                <div class="row">
                    <img class="img-fluid w-25 h-100 m-2" src="../product/img1/IG.jpg" alt="">
                    <img class="img-fluid w-25 h-100 m-2" src="../product/img1/IG1.jpg" alt="">
                    <img class="img-fluid w-25 h-100 m-2" src="../product/img1/IG2.jpg" alt="">
                    <img class="img-fluid w-25 h-100 m-2" src="../product/img1/IG8.jpg" alt="">
                    <img class="img-fluid w-25 h-100 m-2" src="../product/img1/IG7.jpg" alt="">
                    <img class="img-fluid w-25 h-100 m-2" src="../product/img1/IG10.jpg" alt="">
                </div>
            </div>
        </div>

        <div class="copyright mt-5">
            <div class="row container mx-auto">
                <div class="col-lg-3 col-md-6 col-12 mb-4">
                    <img src="../product/img1/payment.png" alt="">
                </div>
                <div class="col-lg-4 col-md-6 col-12  text-nowrap mb-2">
                    <p>MWS eCommerce © 2021. All Rights Reserved</p>
                </div>
                <div class="col-lg-4 col-md-6 col-12">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-linkedin-in"></i></a>
                </div>
            </div>
        </div>

    </footer>
    <div class="select">
		
	</div>
    <script type="text/javascript" src="js/main.js"></script>

</body></html>