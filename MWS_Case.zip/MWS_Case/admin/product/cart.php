<?php 
  include("index.php "); 
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MWS-Case Store</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" 
    integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <link rel="stylesheet" href="MWS.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" 
    integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>
    <link rel="icon" href="img/product/Icon.jfif">
    <style>p.groove {border-style: groove;}</style>
    <title>Cart</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white py-3 fixed-top">
        <div class="container">
            <img src="../product/img1/logo1.png" alt="" width="100px" height="100px">        
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav ml-auto">
            
                    <li class="nav-item">
                        <a class="nav-link active" aria-current="page" href="MWS.html">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../product/indexx.html">Admin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#featured">Shop</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#footer">Contact Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="../product/create_account.html">Sign up</a>
                    </li>
                    <li class="nav-item">
                        <i class="fal fa-search"></i>
                    </li>
                    <li>
                        <a href="cart.php" class="nav-link btn "><i class="far fa-shopping-bag">(0)</i></a>
                    </li> 
                </ul> <br> <br>
                <li class="nav-item" id="account-info" style="list-style: none;">
                    <button id="btn-login" class="btn btn-outline-dark ms-3" 
                    data-bs-toggle="modal" data-bs-target="#frm-login">Login</button>
                </li>
            </div>
        </div>
      </nav>

      <!-- Modal -->
    <form class="modal fade" id="frm-login" tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Login</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="form-floating mb-3">
                        <input type="username" class="form-control" id="username" placeholder="Username" required>
                        <label for="username">Username</label>
                    </div>
                    <div class="form-floating">
                        <input type="password" class="form-control" id="password" placeholder="Password" required>
                        <label for="password">Password</label>
                    </div>
                </div>

                <div class="modal-footer border-0 justify-content-center">
                    <button type="submit" class="btn btn-success">Login</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                </div>
            </div>
        </div>
    </form>
    <div class="container mt-3">
        <div class="row product-list" id="product-list"></div>
    </div>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
    <script src="js/database.js"></script>
    <script src="js/index.js"></script>
    
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center border rounded bg-white my-5">
                <h1>MY CART</h1>
            </div>

            <div class="col-lg-9">
            <table class="table">
                <thead class="text-center">
                    <tr>
                        <th scope="col">Serial No.</th>
                        <th scope="col">Item Name</th>
                        <th scope="col">Item Price</th>
                        <th scope="col">Quantity</th>
                        <th scope="col"></th>
                    </tr>
                </thead>
                <tbody >
                    <?php 
                        $total=0;
                        if(isset($_SESSION['cart']))
                        {
                            foreach($_SESSION['cart'] as $key => $value)
                            {
                                $sr=$key+1;
                                $total=$total+$value['Price'];
                                echo"
                                <tr>
                                    <td>$sr</td>
                                    <td>$value[Item_Name]</td>
                                    <td>$value[Price]</td>
                                    <td><input class='text-center' type='number' value='$value[Quantity]' min='1' max='10'></td>
                                    <td>
                                    <form action='manage_cart.php'method='POST'>
                                        <button name='Remove_Item' class='btn btn-sm btn-outline-danger'>REMOVE</button>
                                        <input type='hidden' name='Item_Name' value='$value[Item_Name]'>
                                    </form>
                                    </td>
                                </tr>
                                ";
                            }
                        }
                    ?>
                </tbody>
                </table>
            </div>

            <div class="col-lg-3">
                <div class="border bg-light rounded p-4">
                    <h4>Total:</h4>
                    <h5 class="text-right"><?php echo $total ?></h5>
                    <br>
                    <form>
                    <div class="form-check">
                        <input class="form-check-input" type="radio" name="exampleRadios" id="exampleRadios1" value="option1" checked>
                        <label class="form-check-label" for="exampleRadios1">
                            Cash On Delivery
                        </label>
                    </div>
                    <br>
                        <button class="btn btn-primary btn-block">Make Purchase</button>
                        <style>
                            .btn-primary{
                                background-color:#000;
                                border-radius: 20px;
                                color:#fff;
                            }
                            .btn-primary:hover{
                                background-color: coral;
                            }
                        </style>
                    </form>
                </div>
            </div>

        </div>
    </div>
</body>
</html>